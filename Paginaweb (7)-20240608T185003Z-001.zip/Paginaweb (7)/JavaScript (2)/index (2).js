function color(id, color) {
  document.getElementById(id).style.backgroundColor = color;
}
function color2(id, color) {
  document.getElementById(id).style.backgroundColor = color;
}
function color3(id, color) {
  document.getElementById("mate2").style.backgroundColor = color;
}
function color4(id, color) {
  document.getElementById("mate2").style.backgroundColor = color;
}
function color5(id, color) {
  document.getElementById("mate3").style.backgroundColor = color;
}
function color6(id, color) {
  document.getElementById("mate3").style.backgroundColor = color;
}
function color7(id, color) {
  document.getElementById("mate4").style.backgroundColor = color;
}
function color8(id, color) {
  document.getElementById("mate4").style.backgroundColor = color;
}
function color9(id, color) {
  document.getElementById("mate5").style.backgroundColor = color;
}
function color10(id, color) {
  document.getElementById("mate5").style.backgroundColor = color;
}
function color11(id, color) {
  document.getElementById("textovideo").style.backgroundColor = color;
}
function color12(id, color) {
  document.getElementById("textovideo").style.backgroundColor = color;
}
function color13(id, color) {
  document.getElementById("texto").style.backgroundColor = color;
}
function color14(id, color) {
  document.getElementById("texto").style.backgroundColor = color;
}
function color15(id, color) {
  document.getElementById("texto1").style.backgroundColor = color;
}
function color16(id, color) {
  document.getElementById("texto1").style.backgroundColor = color;
}