function cambiarColor() {
    document.getElementById("titulo").style.color = "#C00000";
}

function cambiarColor2() {
    document.getElementById("titulo").style.color = "black";
}