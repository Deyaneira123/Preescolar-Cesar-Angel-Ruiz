function cambiar(img){
    img.src = "./indeximagenes/1principal.jpg";
}

function cambiar2(){
    document.getElementById("imgfooter").src = "./indeximagenes/entrada.jpeg";
}