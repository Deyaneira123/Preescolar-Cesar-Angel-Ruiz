function enviar(){
    document.getElementById("datos").style.display = "block";
    document.getElementById("datos").innerHTML = "<br> ¡Gracias por darnos una oportunidad Llamar: 9515680277"
}